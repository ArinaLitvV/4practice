n=int(input("n="))
a=1
c=0
for i in range (1,n+1):
        a*=i
        c+=a
print(c)    
    
    
