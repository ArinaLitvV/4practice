A=int(input("A="))
B=int(input("B="))
while A<=B:
    for i in range (A,B+1):
        print (i)
