print("Введите n<=9")
n = int(input("n="))
if n<=9 :
    for i in range(1, n + 1):
        for j in range(1, i + 1):
            print(j, sep='', end='')
        print()
else:
    print("Ощибка. n>9 ")
