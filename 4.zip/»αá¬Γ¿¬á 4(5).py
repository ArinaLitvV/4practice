n=int(input("n="))
c=0
for i in range (1,n+1):
    i=i**3
    c+=i
print (c)
    
